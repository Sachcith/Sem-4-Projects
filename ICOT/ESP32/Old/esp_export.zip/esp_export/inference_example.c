// Example: Bee Audio Classification on ESP32
// Uses TFLite Micro to run Student MLP inference
//
// Pipeline on ESP32:
//   1. Capture audio (I2S microphone)
//   2. Compute STFT spectrogram
//   3. Compute DWT scalogram
//   4. Extract 70 handcrafted features
//   5. Normalize features (StandardScaler)
//   6. Run MLP inference (TFLite Micro)
//   7. Get predicted class

#include "student_model.h"
#include "scaler_params.h"
#include "feature_extraction.h"

#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

// Tensor arena size (adjust based on model size)
#define TENSOR_ARENA_SIZE 16384  // 16 KB should be enough for MLP

static uint8_t tensor_arena[TENSOR_ARENA_SIZE];

// Initialize TFLite Micro interpreter (call once at startup)
static tflite::MicroInterpreter* interpreter = nullptr;
static TfLiteTensor* input_tensor = nullptr;
static TfLiteTensor* output_tensor = nullptr;

void init_model() {
    const tflite::Model* model = tflite::GetModel(student_model);
    
    // Register only the ops needed by our MLP
    static tflite::MicroMutableOpResolver<5> resolver;
    resolver.AddFullyConnected();
    resolver.AddRelu();
    resolver.AddSoftmax();
    resolver.AddMul();       // For BatchNorm
    resolver.AddAdd();       // For BatchNorm
    
    static tflite::MicroInterpreter static_interpreter(
        model, resolver, tensor_arena, TENSOR_ARENA_SIZE
    );
    interpreter = &static_interpreter;
    interpreter->AllocateTensors();
    
    input_tensor = interpreter->input(0);
    output_tensor = interpreter->output(0);
}

// Run inference on pre-computed spectrograms
// Returns predicted class index (0-5)
int classify_bee_audio(
    const float* stft_spec, int n_freq_stft, int n_time_stft,
    const float* dwt_spec, int n_freq_dwt, int n_time_dwt
) {
    // Step 1: Extract 70 features
    float features[TOTAL_FEATURES];
    extract_all_features(
        stft_spec, n_freq_stft, n_time_stft,
        dwt_spec, n_freq_dwt, n_time_dwt,
        features
    );
    
    // Step 2: Normalize (StandardScaler)
    normalize_features(features);
    
    // Step 3: Copy to input tensor
    for (int i = 0; i < NUM_FEATURES; i++) {
        input_tensor->data.f[i] = features[i];
    }
    
    // Step 4: Run inference
    interpreter->Invoke();
    
    // Step 5: Get predicted class (argmax)
    int best_class = 0;
    float best_prob = output_tensor->data.f[0];
    for (int i = 1; i < NUM_CLASSES; i++) {
        if (output_tensor->data.f[i] > best_prob) {
            best_prob = output_tensor->data.f[i];
            best_class = i;
        }
    }
    
    printf("Prediction: %s (%.1f%%)\n", CLASS_NAMES[best_class], best_prob * 100);
    return best_class;
}
